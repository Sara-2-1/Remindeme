//
//  Home.swift
//  Remindeme
//
//  Created by Sarah ali  on 27/03/1446 AH.
//

import SwiftUI

struct Home: View {
    var body: some View {
       
                #Preview {
                    Home()
                }
            }
