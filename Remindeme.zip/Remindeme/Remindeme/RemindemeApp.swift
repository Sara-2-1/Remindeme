//
//  RemindemeApp.swift
//  Remindeme
//
//  Created by Sarah ali  on 26/03/1446 AH.
//

import SwiftUI

@main
struct RemindemeApp: App {
    var body: some Scene {
        WindowGroup {
            Asma()
        }
    }
}
