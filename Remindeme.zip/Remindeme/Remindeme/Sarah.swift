//
//  Sarah.swift
//  Remindeme
//
//  Created by Sarah ali  on 26/03/1446 AH.
//

import SwiftUI

struct Sarah: View {
    var body: some View {
        NavigationView { // Wrap everything in a NavigationView
            ZStack {
                Color.white.ignoresSafeArea()
                
                VStack {
                    Spacer()
                    Image("image2")
                        .scaledToFit()
                        .padding()
                    
                    Text("Remind me")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .padding(.bottom, 10)
                    
                    Text("An application that helps users manage their eating habits by sending notifications for meal times and reminding them when food expires.")
                        .multilineTextAlignment(.center)
                        .foregroundColor(.gray)
                        .padding()
                    
                    Spacer()
                    
                    HStack {
                        Spacer()
                        
                        // NavigationLink to navigate to ContentView
                        NavigationLink(destination: Norah()) {
                            HStack {
                                Text("Next")
                                Image(systemName: "arrow.forward")
                                    .resizable()
                                    .frame(width: 20, height: 15)
                            }
                            .foregroundColor(.color2)
                            .padding(.trailing)
                        }
                    }
                }
                .padding()
            }
                        } .navigationBarBackButtonHidden(true)
                    }
                }
            
                            
    #Preview {
        Sarah()
    }



